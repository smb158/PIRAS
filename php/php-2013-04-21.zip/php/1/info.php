<?php phpinfo() ; ?>
